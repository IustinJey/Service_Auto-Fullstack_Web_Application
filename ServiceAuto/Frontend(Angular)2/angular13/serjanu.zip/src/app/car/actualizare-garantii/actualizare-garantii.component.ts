import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-actualizare-garantii',
  templateUrl: './actualizare-garantii.component.html',
  styleUrls: ['./actualizare-garantii.component.css']
})
export class ActualizareGarantiiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
