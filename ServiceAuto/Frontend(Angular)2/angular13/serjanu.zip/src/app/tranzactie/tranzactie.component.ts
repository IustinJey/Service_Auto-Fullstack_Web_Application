import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tranzactie',
  templateUrl: './tranzactie.component.html',
  styleUrls: ['./tranzactie.component.css']
})
export class TranzactieComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
