import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-card-client',
  templateUrl: './card-client.component.html',
  styleUrls: ['./card-client.component.css']
})
export class CardClientComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
